﻿using System;

namespace bai2
{
    class Program
    {
        public static void nhap(int[] a, int n)
        {
            for (int i = 0; i < n; i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }
        }
        public static void xuat(int[] a, int n)
        {
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("{0}", a[i]);
            }
        }
        public static void MangCL(int[] a, int n)
        {
           for(int i = 0; i < n; i++)
            {
                if (a[i] % 2 == 0)
                {
                    Console.WriteLine("mang chan {0}", a[i]);
                }
                if (a[i] % 2 == 1)
                {
                    Console.WriteLine("mang le {0}", a[i]);
                }
            }
        }
        static void Main(string[] args)
        {
            int n;
            int[] a;
            Console.WriteLine("nhap mang n");
            n = Convert.ToInt32(Console.ReadLine());
            a = new int[n];
            nhap(a, n);
            Console.WriteLine("xuat mang");
            xuat(a, n);
            Console.WriteLine("2 mang chan le");
            MangCL(a, n);


        }
    }
}
