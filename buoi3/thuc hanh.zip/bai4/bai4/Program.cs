﻿using System;

namespace bai4
{
    class Program
    {
       public static void cuchuong()
        {
           for(int i = 1; i <= 10; i++)
            {
                for(int j = 1; j < 10; j++)
                {
                    Console.WriteLine("{0}*{1}={2}",i,j,(i*j));
                }
            }
        }
        static void Main(string[] args)
        {

            cuchuong();
        }
    }
}
