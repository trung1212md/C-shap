﻿using System;
using System.IO;
namespace bai10
{
    class Program
    {
        static void Main(string[] args)
        {
            string writeText = "hello word";
            File.WriteAllBytes("filename.txt", writeText);
        }
    }
}
