﻿using System;

namespace bai6
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            bool check = true;
            do
            {
                Console.WriteLine("nhap a");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("nhap b");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("nhap c");
                c = Convert.ToInt32(Console.ReadLine());

            } while (a <= 0 || b <= 0 || c <= 0);
            if ((a + b <= c) || (a + c <= b) || (c + b <= a))
                check = false;

                if (check)
                    Console.WriteLine("day la tam giac");
                else
                    Console.WriteLine("day ko la tam giac");
        }
    }
}
