﻿using System;

namespace bai3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            string pt;
            pt = Convert.ToString(Console.ReadLine());
            if (pt == "+")
            {
                Console.WriteLine("{0}", (a + b));
            }
            if (pt == "-")
            {
                Console.WriteLine("{0}", (a - b));
            }
            if (pt == "*")
            {
                Console.WriteLine("{0}", (a * b));
            }
            if (pt == "/")
            {
                Console.WriteLine("{0}", (a / b));
            }
        }
    }
}
