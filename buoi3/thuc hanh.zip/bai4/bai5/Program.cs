﻿using System;

namespace bai5
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
           
            n = Convert.ToInt32(Console.ReadLine());
            while (n <= 100)
            {
                Console.WriteLine("nhap trong khoan 100");
                break;
            }
        }
    }
}
