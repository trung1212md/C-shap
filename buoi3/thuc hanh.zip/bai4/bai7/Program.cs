﻿using System;

namespace bai7
{
    class Program
    {
        public static void nhap(int []a,int n) 
        {
            for(int i = 0; i < n; i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }
        }
        public static void xuat(int []a,int n)
        {
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine("{0}", a[i]);
            }
        }
        public static void TongL(int []a,int n)
        {
            int tong = 0;
            for(int i = 0; i < n; i++)
            {
                if (a[i] % 2 == 1)
                {
                   tong += a[i];
                }
            }
            Console.WriteLine("tong la {0}", tong);
        }
        static void Main(string[] args)
        {
            int n;
            int[] a;
            Console.WriteLine("nhap mang n");
            n = Convert.ToInt32(Console.ReadLine());
            a = new int[n];
            nhap(a, n);
            Console.WriteLine("xuat mang");
            xuat(a, n);
            Console.WriteLine("tong l");
            TongL(a, n);


        }
    }
}
